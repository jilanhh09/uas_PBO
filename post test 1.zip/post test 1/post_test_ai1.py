import numpy as np

# Mendefinisikan dua buah array a dan b
arrayA = np.array([[1, 2, 3],
                   [4, 5, 6],
                   [7, 8, 9]])

arrayB = np.array([[9, 8, 7],
                   [6, 5, 4],
                   [3, 2, 1]])

# No. 1 Penjumlahan a dan b
penjumlahan = np.add(arrayA, arrayB)

# No. 2 Perkalian a dan b
perkalian = np.multiply(arrayA, arrayB)

# Menampilkan hasil
print("Array A:")
print(arrayA)

print("\nArray B:")
print(arrayB)

print("\nPenjumlahan:")
print(penjumlahan)

print("\nPerkalian:")
print(perkalian)



